package mapa;

import gatunki.Zwierze;

public class Pole {

    Zwierze obecny_osobnik;

    public Pole(Zwierze obecny_osobnik) {
        this.obecny_osobnik = obecny_osobnik;
    }

    public Zwierze getObecny_osobnik() {
        return obecny_osobnik;
    }
    
    

}
