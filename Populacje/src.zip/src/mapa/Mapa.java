package mapa;

import gatunki.Zwierze;
import java.awt.Point;
import java.util.List;
import populacje.Parametry;

public class Mapa {

//    private final int _szerokosc, _wysokosc;
    private Pole[][] pola;
    Parametry parametry;

    public Mapa(Parametry _parametry) {
        this.parametry = _parametry;
        inicjujPola();
    }

    private void inicjujPola() {
        pola = new Pole[parametry.getSzerokoscMapy()][];
        for (int i = 0; i < parametry.getSzerokoscMapy(); i++) {
            pola[i] = new Pole[parametry.getWysokoscMapy()];
        }
        resetujPola();
    }

    private void resetujPola() {
        for (int i = 0; i < parametry.getSzerokoscMapy(); i++) {
            for (int j = 0; j < parametry.getWysokoscMapy(); j++) {
                pola[i][j] = new Pole(null);
            }
        }
    }

    public void aktualizujMape(List<Zwierze> zwierzeta) {
        resetujPola();
        Point p;
        for (Zwierze zwierze : zwierzeta) {
            p = zwierze.getPoint();
            pola[p.x][p.y] = new Pole(zwierze);
        }
    }

    public int getSzerokosc() {
        return parametry.getSzerokoscMapy();
    }

    public int getWysokosc() {
        return parametry.getWysokoscMapy();
    }

    public Pole getPole(int x, int y) {
        return pola[x][y];
    }

    public boolean isEmpty(int x, int y) {
        return (pola[x][y].getObecny_osobnik() == null);
    }
    
    public void setCell(int x, int y, Zwierze z) {
        pola[x][y] = new Pole(z);
    }

}
