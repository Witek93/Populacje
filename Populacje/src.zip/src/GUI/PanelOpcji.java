package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import populacje.Parametry;

public class PanelOpcji extends JPanel {

    Parametry parametry;

    public PanelOpcji(Parametry _parametry) {
        super(new BorderLayout());
        this.parametry = _parametry;
        add(new JLabel("Opcje symulacji", JLabel.CENTER), BorderLayout.NORTH);
        setBackground(Color.white);
        add(stworzPanelSuwakow(), BorderLayout.CENTER);
        add(stworzPanelPrzyciskow(), BorderLayout.SOUTH);
    }

    private JPanel stworzPanelPrzyciskow() {
        JPanel panel = new JPanel();
        GridLayout layout = new GridLayout(0, 1, 5, 5);
        panel.setLayout(layout);

        JButton start = new JButton("Start");
        start.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (parametry.isStarted()) {
                    start.setText("Start");
                    parametry.setStarted(false);
                } else {
                    start.setText("Pauza");
                    parametry.setStarted(true);
                }

            }
        });

        panel.add(start);
        panel.add(new JButton("Aktualizuj"));
        panel.add(new JButton("Resetuj"));
        panel.add(new JButton("Wykres populacji"));
        return panel;
    }

    private JPanel stworzPanelSuwakow() {
        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));

        JSlider ilosc_krolikow = new SuwakParametru("Ilość królików",
                parametry.getMaxKrolikow(), parametry.getIloscKrolikow());

        JSlider ilosc_wilkow = new SuwakParametru("Ilość wilków",
                parametry.getMaxWilkow(), parametry.getIloscWilkow());

        JSlider szerokosc = new SuwakParametru("Szerokość mapy", parametry.MAX_SZEROKOSC_MAPY,
                parametry.getSzerokoscMapy());

        szerokosc.addChangeListener((ChangeEvent e) -> {
            parametry.setSzerokoscMapy(szerokosc.getValue());
            update(ilosc_krolikow, parametry.getMaxKrolikow());
            update(ilosc_wilkow, parametry.getMaxWilkow());
        });

        JSlider wysokosc = new SuwakParametru("Wysokość mapy", parametry.MAX_WYSOKOSC_MAPY,
                parametry.getWysokoscMapy());

        wysokosc.addChangeListener((ChangeEvent e) -> {
            parametry.setWysokoscMapy(wysokosc.getValue());
            update(ilosc_krolikow, parametry.getMaxKrolikow());
            update(ilosc_wilkow, parametry.getMaxWilkow());
        });

        panel.add(szerokosc);
        panel.add(wysokosc);
        panel.add(ilosc_krolikow);
        panel.add(ilosc_wilkow);

        return panel;
    }

    private void update(JSlider slider, int max) {
        if (slider.getValue() > max) {
            slider.setValue(max);
        }
        slider.setMaximum(max);
        slider.setMajorTickSpacing(max / 5);
    }

}
