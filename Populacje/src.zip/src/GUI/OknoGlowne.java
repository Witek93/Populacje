package GUI;

import gatunki.Krolik;
import gatunki.Wilk;
import gatunki.Zwierze;
import java.awt.*;
import java.util.LinkedList;
import java.util.List;
import javax.swing.*;
import mapa.Mapa;
import populacje.Parametry;

public class OknoGlowne {

    JFrame frame;
    PanelMapy panelMapy;
    PanelOpcji panelOpcji;
    final private String nazwa;
    final private Parametry parametry;
    final private Mapa mapa;

    public OknoGlowne(String _nazwa, Parametry _parametry, Mapa _mapa) {
        this.nazwa = _nazwa;
        this.parametry = _parametry;
        this.mapa = _mapa;
        panelMapy = new PanelMapy(this.mapa);
        panelOpcji = new PanelOpcji(this.parametry);

        inicjuj();

        frame.add(panelMapy, BorderLayout.CENTER);
        frame.add(panelOpcji, BorderLayout.EAST);

        frame.setVisible(true);
    }

    private void inicjuj() {
        frame = new JFrame(nazwa);
        frame.setLayout(new BorderLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 500);
    }

    public void pokaz(List<Krolik> kroliki, List<Wilk> wilki) {
        List<Zwierze> zwierzeta = new LinkedList<>(kroliki);
        zwierzeta.addAll(wilki);
        mapa.aktualizujMape(zwierzeta);
        panelMapy.aktualizuj();
    }

}
