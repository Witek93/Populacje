package gatunki;

import java.awt.Color;
import java.awt.Point;

public class Wilk extends Zwierze {

    final private static int WIEK_PLODNY = 10;
    private int glod;

    public Wilk(Point point) {
        setWiek(0);
        setZdrowie(25);
        setPoint(point);
        setGlod(0);
    }

    @Override
    public Color getColor() {
        return Color.red;
    }

    public int getGlod() {
        return glod;
    }

    public void incGlod() {
        this.glod++;
    }

    public void decGlod() {
        this.glod = 0;
    }

    private void setGlod(int glod) {
        this.glod = glod;
    }
}
