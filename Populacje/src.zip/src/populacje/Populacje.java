package populacje;

import GUI.OknoGlowne;
import mapa.Mapa;
import wykresy.Wykres;

public class Populacje {

//    public static void main(String[] args) throws InterruptedException {
//
//        Parametry parametry = new Parametry(500, 200, 50, 50, false);
//        Symulator s = new Symulator(parametry);
//        Mapa mapa = new Mapa(parametry);
//
//        OknoGlowne okno = new OknoGlowne("Symulacja populacji", parametry, mapa);
//
//        while (true) {
//            while (parametry.isStarted()) {
//                s.rozlokujLosowo();
//                okno.pokaz(s.getZwierzeta());
//                Thread.sleep(1000);
//            }
//            Thread.sleep(10);
//        }
//    }
    public static void main(String[] args) throws Exception {
        // potrzebne, aby szerokość mapy mogła być większa niż 45
        System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");

        Parametry parametry = new Parametry(1000, 20, 50, 50, true);
        Mapa mapa = new Mapa(parametry);
        Symulacja s = new Symulacja(parametry, mapa);

        OknoGlowne okno = new OknoGlowne("Symulacja populacji", parametry, mapa);

        Wykres wykresPopulacji = new Wykres("Wykres populacji", "czas", "liczebność");
        wykresPopulacji.dodajSerie("Populacja królików", "króliki");
        wykresPopulacji.dodajSerie("Populacja wilków", "wilki");

        wykresPopulacji.iniciuj();
        for (int i = 0;;) {
            while (parametry.isStarted()) {
                s.symuluj();
                wykresPopulacji.getSeria("króliki").dodajPunkt(i, s.getKroliki().size());
                wykresPopulacji.getSeria("wilki").dodajPunkt(i, s.getWilki().size());
                okno.pokaz(s.getKroliki(), s.getWilki());
                Thread.sleep(1000);
                i++;
            }
            Thread.sleep(10);
        }
    }
}
