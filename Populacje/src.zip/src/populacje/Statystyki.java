
package populacje;

import wykresy.Wykres;


public class Statystyki {
    Wykres populacjaKrolikow, populacjaWilkow;
    
//    --trzeba jebnąć tutaj singletonem
}
