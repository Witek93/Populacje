package populacje;

import gatunki.Krolik;
import gatunki.Wilk;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import mapa.Mapa;

public class Symulacja {

    final private List<Point> wolnePola;
    final private List<Krolik> kroliki;
    final private List<Wilk> wilki;
    final private Parametry parametry;
    final private Mapa mapa;

    public Symulacja(Parametry _parametry, Mapa mapa) throws Exception {
        this.parametry = _parametry;
        this.kroliki = new LinkedList();
        this.wilki = new LinkedList();
        this.mapa = mapa;
        wolnePola = new ArrayList();
        for (int i = 0; i < mapa.getSzerokosc(); i++) {
            for (int j = 0; j < mapa.getWysokosc(); j++) {
                wolnePola.add(new Point(i, j));
            }
        }

        for (int i = 0; i < parametry.getIloscKrolikow(); i++) {
            Random los = new Random();
            int index = los.nextInt(wolnePola.size());
            kroliki.add(new Krolik(wolnePola.get(index)));
            wolnePola.remove(index);
        }

        for (int i = 0; i < parametry.getIloscWilkow(); i++) {
            Random los = new Random();
            int index = los.nextInt(wolnePola.size());
            wilki.add(new Wilk(wolnePola.get(index)));
            wolnePola.remove(index);
        }
    }

    public void przemiescKroliki() {
        for (Krolik elem : kroliki) {
            int poprzedniX = elem.getX();
            int poprzedniY = elem.getY();
            Random gen = new Random();
            int newX = elem.getX() + gen.nextInt(3) - 1;
            int newY = elem.getY() + gen.nextInt(3) - 1;

            if (newX >= 0 && newX < mapa.getSzerokosc() && newY >= 0
                    && newY < mapa.getWysokosc() && mapa.isEmpty(newX, newY)) {
                wolnePola.add(new Point(poprzedniX, poprzedniY));
                mapa.setCell(poprzedniX, poprzedniY, null);
                elem.movePoint(new Point(newX, newY));
                mapa.setCell(newX, newY, new Krolik(new Point(newX, newY)));
            }
        }
    }

    public void przemiescWilki() {
        Iterator<Wilk> itr = wilki.listIterator();
        while (itr.hasNext()) {
            Wilk elem = itr.next();
            Random gen = new Random();
            int poprzedniX = elem.getX();
            int poprzedniY = elem.getY();
            int newX = poprzedniX + gen.nextInt(11) - 5;
            int newY = poprzedniY + gen.nextInt(11) - 5;

            // jeśli wylosowane nowe miejsce jest wolne
            if (newX >= 0 && newX < mapa.getSzerokosc() && newY >= 0
                    && newY < mapa.getWysokosc()) {
                //oznacz stare pole jako wolne
                wolnePola.add(new Point(poprzedniX, poprzedniY));
                mapa.setCell(poprzedniX, poprzedniY, null);
                // i przemiesc wilka
                elem.movePoint(new Point(newX, newY));
                mapa.setCell(newX, newY, new Wilk(new Point(newX, newY)));
                elem.incGlod();
                // sprawdz czy wilk natrafil na krolika
                for (Krolik ofiara : kroliki) {
                    if (ofiara.getX() == newX && ofiara.getY() == newY) {
                        kroliki.remove(ofiara);
                        elem.decGlod();
                        break;
                    }
                }
            }

            // wygłodniałe wilki po 30 dniach umierają
            if (elem.getGlod() == 60 && itr.hasNext()) {
                itr.next();
                itr.remove();
                wolnePola.add(new Point(poprzedniX, poprzedniY));
                mapa.setCell(poprzedniX, poprzedniY, null);
            }
        }
    }

    void rozmnazajKroliki() {
        int liczbaPlodnych = 0;
        for (Krolik krolik : kroliki) {
            // zwiekszamy wiek krolikow o 1/3 roku = zakladamy ze wszystkie plodne kroliki rozmnazaja sie 3 razy w roku
            krolik.setWiek(krolik.getWiek() + 0.33);
            if (krolik.getWiek() > 0.5) {
                liczbaPlodnych++;
            }
        }
        int pary = liczbaPlodnych / 2;
        for (int i = 0; i < pary; i++) {
            Random gen = new Random();
            int potomstwo = gen.nextInt(4) + 2;
            for (int j = 0; j < potomstwo; j++) {
                if (!wolnePola.isEmpty() && kroliki.size() < 2000) {
                    kroliki.add(new Krolik(wolnePola.get(0)));
                    wolnePola.remove(0);
                }
            }
        }
    }

    void rozmnazajWilki() {
        int liczbaPlodnych = 0;
        for (Wilk wilk : wilki) {
            // zwiekszamy wiek wilkow o 1 rok - zakladamy ze wszystkie plodne wilki rozmnazaja sie co roku
            wilk.setWiek(wilk.getWiek() + 1);
            if (wilk.getWiek() >= 2.0) {
                liczbaPlodnych++;
            }
        }
        int pary = liczbaPlodnych / 2;
        for (int i = 0; i < pary; i++) {
            Random gen = new Random();
            int potomstwo = gen.nextInt(8) + 4;
            for (int j = 0; j < potomstwo; j++) {
                if (!wolnePola.isEmpty() && wilki.size() < 250) {
                    wilki.add(new Wilk(wolnePola.get(0)));
                    wolnePola.remove(0);
                }
            }
        }
    }

    public void stareKroliki() {
        Iterator<Krolik> itr = kroliki.listIterator();
        while (itr.hasNext()) {
            Krolik elem = itr.next();
            if (elem.getWiek() == 5 && itr.hasNext()) {
                int x = elem.getX();
                int y = elem.getY();
                itr.next();
                itr.remove();
                wolnePola.add(new Point(x, y));
                mapa.setCell(x, y, null);
            }
        }
    }

    public void stareWilki() {
        Iterator<Wilk> itr = wilki.listIterator();
        while (itr.hasNext()) {
            Wilk elem = itr.next();
            if (elem.getWiek() == 10 && itr.hasNext()) {
                int x = elem.getX();
                int y = elem.getY();
                itr.next();
                itr.remove();
                wolnePola.add(new Point(x, y));
                mapa.setCell(x, y, null);
            }
        }
    }

    // jedno wywołanie funkcji to okres 1 roku zycia populacjii
    public void symuluj() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 122; j++) {
                przemiescKroliki();
                przemiescWilki();
            }
            rozmnazajKroliki();
        }
        rozmnazajWilki();
        stareKroliki();
        stareWilki();
    }

    final public List<Wilk> getWilki() {
        return wilki;
    }

    final public List<Krolik> getKroliki() {
        return kroliki;
    }
}
